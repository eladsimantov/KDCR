---> The "Derivations.mlx" file, was used to derive any symbolic formulas. 
---> The "Main.m" file,  is used to calculate any numerical value results.
---> All plots are located in the folders named by their task and joint vector values.
---> The IK and FK functions are called "inv_kin.m" and "forward_kin.m".
---> The txt files ("errors.txt" and "singularities_output_text.txt") 
are just copies of the cmd window outputs for values that were later copied to the final report.